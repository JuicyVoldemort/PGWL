<?php

use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MapController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PointController;
use App\Http\Controllers\PolylineController;
use App\Http\Controllers\PolygonController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [MapController::class, 'index'])->name('index');
Route::get('/table', [MapController::class, 'table'])->name('table');

//edit point
Route::get('/edit-point/{id}', [PointController::class, 'edit'])->name('edit-point');
//update point
Route::patch('/update-point/{id}', [PointController::class, 'update'])->name('update-point');
//create point
Route::post('/store-point', [PointController::class, 'store'])->name('store-point'); //rute nyimpen data lewat store point
//delete point
Route::delete('/delete-point/{id}',[PointController::class, 'destroy'])->name('delete-point');

//edit polyline
Route::get('/edit-polyline/{id}', [PolylineController::class, 'edit'])->name('edit-polyline');
//update polyline
Route::patch('/update-polyline/{id}', [PolylineController::class, 'update'])->name('update-polyline');
//create polyline
Route::post('/store-polyline', [PolylineController::class, 'store'])->name('store-polyline'); //rute nyimpen data lewat store polyline
//delete polyline
Route::delete('/delete-polygon/{id}',[PolylineController::class, 'destroy'])->name('delete-polyline');

//edit polygon
Route::get('/edit-polygon/{id}', [PolygonController::class, 'edit'])->name('edit-polygon');
//create polygon
Route::post('/store-polygon', [PolygonController::class, 'store'])->name('store-polygon'); //rute nyimpen data lewat store polygon
//delete polygon
Route::delete('/delete-polygon/{id}',[PolygonController::class, 'destroy'])->name('delete-polygon');

Route::get('/index', function () {
    return view('index');
});

Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');



Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

//table
Route::get('/table-point', [PointController::class, 'table'])->name('table-point');


require __DIR__.'/auth.php';
