<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h3>Coal Power Plants</h3>
            </div>
            <div class="card body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Jumlah Emisi</th>
                            <th>Coordinates</th>
                            <th>Image</th>
                            <th>Created at</th>
                        </tr>
                    </thead>


                    <tbody>
                        <?php $no = 1 ?>
                        <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?> </td>
                                <td><?php echo e($p->name); ?> </td>
                                <td><?php echo e($p->description); ?> </td>
                                <td><?php echo e($p->geom); ?> </td>
                            <td>
                                <img src="<?php echo e(asset('storage/images/' .$p->image)); ?>" alt="" width="200">
                            </td>
                            <td><?php echo e($p->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pgwl\resources\views/table-point.blade.php ENDPATH**/ ?>