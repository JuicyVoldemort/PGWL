<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="card-container bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <div class="card shadow-sm rounded-lg">
                    <div class="card-header bg-gray-100 dark:bg-gray-700 p-4 rounded-t-lg">
                        <h3 class="card-title text-lg font-semibold">How many Powerplants are there that are still using Coal?</h3>
                    </div>
                    <div class="card-body p-4 text-center"> <!-- Center align content -->
                        <div class="row justify-content-center"> <!-- Center the column -->
                            <div class="col-md-6"> <!-- Set the column width -->
                                <div class="alert alert-primary" role="alert">
                                    <h4 class="text-2xl font-bold">Total Powerplants</h4> <!-- Increase font size -->
                                    <p class="text-xl">{{ $Total_points }}</p> <!-- Increase font size -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="card-container bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <div class="card shadow-sm rounded-lg">
                    <div class="card-body p-4 text-center">
                        <div class="alert alert-danger" role="alert">
                            <div>
                                <i class="fa-solid fa-house-crack" style="font-size: 7em;"></i> <!-- Adjust the font size as needed -->
                            </div>
                            <h2 class="text-2xl font-bold mb-4">
                                The Environmental Impact of Coal Power Plants
                            </h2>
                            <p class="text-lg mb-4">Coal power plants are major contributors to air pollution, emitting harmful pollutants such as sulfur dioxide, nitrogen oxides, and particulate matter. These pollutants not only cause respiratory diseases and other health issues in humans but also contribute to acid rain, smog, and climate change.</p>
                            <p class="text-lg mb-4">Despite the well-documented environmental and health risks associated with coal power plants, governmental action to phase out or regulate these plants has been insufficient. Many governments have been slow to transition to cleaner and more sustainable energy sources, prioritizing short-term economic interests over long-term environmental and public health concerns.</p>
                            <p class="text-lg mb-4">It is imperative for governments to prioritize the transition to renewable energy sources and implement stricter regulations on coal power plants to mitigate their harmful effects on the environment and public health.</p>
                        </div>
                        <hr>
                        <p>Anda login sebagai <b>{{ Auth::user()->name }}</b> dengan email <i>{{ Auth::user()->email }}</i></p>
                    </div>
                </div>
            </div>
        </div>
    </div>





</x-app-layout>
